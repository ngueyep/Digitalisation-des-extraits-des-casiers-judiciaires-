<?php  
session_start();

 require_once 'conn.php';

//if(isset($_SESSION['user'])){ header('Location:index.php');  //redirection de l'utilisateur non authentifier  die();
  //recuperer les données de l'utilisateur $req = $bd->prepare('SELECT * FROM member WHERE mem_id = ?'); $req ->execute(array($_SESSION['user'])); $data = $req->fetch();}
  ?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/king2.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rechercher</title>
</head>
<body>
   <header>
 <h1> Etes-vous à la recherche de votre extrait de casier judiciaire ? Trouver le facilement ici</h1>
   </header> <br><br>
   <center>
   <div class="container">
    <h1>Entrez vos informations valides </h1><br><br>
  <form action="research_query.php" method="post">
  <div class="form-group">
					<label>numCni</label>
					<input type="text" class="form-control" name="numCni" required/>
				</div><br>
				<div class="form-group">
					<label>Nom</label>
					<input type="text" class="form-control" name="nom" required />
				</div><br>
        <label>numActeNaissance</label>
					<input type="number" class="form-control" name="numActeNaissance" required/>
				</div><br><br>
				<div class="form-group">
					<input type="submit" class="btn btn-primary form-control" name="research"/>
				</div><br>
				
  </form>
  </div>
  </center>
</body>
</html>