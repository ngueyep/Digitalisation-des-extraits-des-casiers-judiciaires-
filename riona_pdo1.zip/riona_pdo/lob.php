<!DOCTYPE html>
<html lang="fr">
<head>
    <link rel="stylesheet" href="css/rio.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <title>Nos services</title>
</head>
<body>
    <header>
        <a class="btn btn-primary" href="index.php" role="button"> Log In </a>
        <a class="btn btn-primary" href="registration.php" role="button"> Sign Up </a>
      
                
    </header>
    <center><h1 class="nos"> NOS SERVICES </h1></center><br><br><br><br><br>
    
 <h1> <p> Le casier judiciaire désormais accessible en ligne </p></h1>    
 <div class="c"> 
<img src="">
<div id="carouselExampleAutoplaying" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="ressources/c.jpg" class="d-block w-100" alt="alto" style="height: 400px;">
    </div>
    <div class="carousel-item">
      <img src="ressources/f.jpg" class="d-block w-100" alt="..." style="height: 400px;" >
    </div>
    <div class="carousel-item">
      <img src="ressources/g.webp" class="d-block w-100" alt="..." style="height: 400px;">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleAutoplaying" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
 </div>
    <p> Le casier judiciaire contient les condamnations d’une personne. Il est « un outil important pour la Justice car il en est sa mémoire. Il traite les condamnations avec le souci de laisser des traces et celui de les effacer.  » <br><br><br> 
         Il existe trois types d’extraits de casier judiciaire, appelés bulletins, dont le contenu varie selon la gravité des sanctions :<br><br> 
        
        - le bulletin n° 1, délivré aux autorités judiciaires et à l ’administration pénitentiaire ;<br>
        
        - le bulletin n° 2, délivré à certaines administrations et organismes privés pour des motifs précis ;<br>
        
        - le bulletin n° 3, qui ne peut être délivré qu’à la personne concernée, ou à son représentant légal s’il s’agit d’un mineur ou d’un majeur sous tutelle.<br><br><br> 
        Désormais, le nouveau site du Casier judiciaire national permet à toute personne de demander l'extrait de son casier judiciaire (bulletin n° 3) via Internet et de le recevoir en ligne, en moins d'une heure si elle est née au cameroun. Auparavant, pour avoir la garantie de l'obtenir dans la journée, il fallait se déplacer dans sa ville natale.</p>   
       
</body>
</html>