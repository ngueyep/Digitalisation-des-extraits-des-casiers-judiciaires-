<?php
ini_set("display_errors", true);
	session_start();
require_once 'conn.php';

	

     
			$nom= $_POST['nom'];
	$check = $conn->prepare('SELECT * FROM casierjudiciaire WHERE nom = ?');
        $check->execute(array($nom));
        $data = $check->fetch();
		$check1= $conn->prepare('SELECT * FROM client WHERE NomCLIENT = ?');
        $check1->execute(array($nom));
        $data1= $check1->fetch();
  

	?>
	 

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="css/king2.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rechercher</title>
</head>
<body>
   <header>
 <h1> </h1>
   </header> <br><br>
   <center>

    <h1>voici votre extrait de casier judiciaire </h1><br><br>
  <form action="" method="post">
  <div class="form-group">
					<label>numCasier</label>
					<input type="text" class="form-control" name="numCasier" value="<?php echo $data['numCasier']?>" disabled/>
				</div><br>
				<div class="form-group">
					<label>nom</label>
					<input type="text" class="form-control" name="nom" value=" <?php echo $data['nom']?> " disabled/>
				</div><br>
				<label>numCni</label>
					<input type="text" class="form-control" name="numCni" value=" <?php echo $data1['numCni']?> " disabled/>
				</div><br><br>
               <label>numActeNaissance</label>
					<input type="text" class="form-control" name="numActeNaissance" value=" <?php echo $data1['numActeNaissance']?> " disabled/>
				</div><br><br>
				<label>etat</label>
					<input type="text" class="form-control" name="etat" value="<?php if($data['etat']==0) { echo "votre casier n est plus vierge"; } else { echo "Neant"; } ?>" disabled />
				
  </form>
  
  </center>
  </body>
</html>

