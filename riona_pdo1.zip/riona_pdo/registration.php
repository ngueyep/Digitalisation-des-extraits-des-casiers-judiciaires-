
<!DOCTYPE html>
<html lang="en">
	<head>
		<link rel="stylesheet" type="text/css" href="css/king2.css"/>
		<meta charset="UTF-8" name="viewport" content="width=device-width, initial-scale=1"/>
	</head>
<body>
<header>
        <div class="logo2">
        <img src="ressources/logo2.jpg" alt="logo" height="10%"width="10%"></img>
        </div>
        <div class="logo1">
            <img src="ressources/logo1.jpg" alt="logo" height="10%"width="10%"></img>
            </div>
    </header><br><br><br><br><br><br>
	<center>
	<div class="container">
			<form action="register_query.php" method="POST">
			<div class="form-group">
					<label>Username</label>
					<input type="text" class="form-control" name="username" />
				</div><br><br>	
				<div class="form-group">
					<label>Firstname</label>
					<input type="text" class="form-control" name="firstname" />
				</div><br><br>
				<div class="form-group">
					<label>E-mail</label>
					<input type="text" class="form-control" name="lastname" />
				</div><br><br>
				
				<div class="form-group">
					<label>Password</label>
					<input type="password" class="form-control" name="password" />
				</div><br><br>
				<br />
				<div class="form-group">
					<button class="btn btn-primary form-control" name="register">s'inscrire</button>
				</div>
				<a href="index.php">se connecter</a>
			</form>
		</div>
		</div>
	</div>
</center>
</body>
</html>